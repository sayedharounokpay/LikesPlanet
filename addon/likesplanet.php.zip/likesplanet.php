<?

$mysiteid=1;

$includes[content].="
	<center>
	<iframe src='http://likesplanet.com/likesplanetaddon.php?siteid=" . $mysiteid . "&userid=" . $thismemberinfo[userid] . "'
        scrolling='no' frameborder='0'
        style='border:none; width:280px; height:1300px'></iframe>
        </center>
";

?>
